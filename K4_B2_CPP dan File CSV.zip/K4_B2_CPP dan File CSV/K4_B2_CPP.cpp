#include <iostream>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <limits>

using namespace std;

#define MAX_PENGGUNA 100
#define MAX_SEPATU 100

// Struct untuk merepresentasikan sepatu
struct Sepatu {
    string merk;
    double harga;
    int stok;
};

struct Pengguna {
    string username;
    string password;
    Sepatu keranjang[MAX_SEPATU];
    int jumlahSepatu = 0;
};

// Database pengguna
Pengguna databasePengguna[MAX_PENGGUNA];
int jumlahPengguna = 0;

// Database sepatu
Sepatu databaseSepatu[MAX_SEPATU] = {
    {"Adidas", 85000, 50},
    {"Converse", 70000, 40},
    {"Nike", 80000, 30},
    {"Puma", 75000, 60},
    {"Vans", 90000, 20}
};
int jumlahSepatu = 5;

// Fungsi untuk menyimpan database pengguna ke dalam file CSV
void simpanDatabasePenggunaKeCSV() {
    ofstream file("akun.csv");
    if (file.is_open()) {
        for (int i = 0; i < jumlahPengguna; ++i) {
            file << databasePengguna[i].username << "," << databasePengguna[i].password << "\n";
        }
        file.close();
    } else {
        cout << "Gagal menyimpan database pengguna ke file." << endl;
    }
}

// Fungsi untuk membaca database pengguna dari file CSV
void bacaDatabasePenggunaDariCSV() {
    ifstream file("akun.csv");
    if (file.is_open()) {
        jumlahPengguna = 0;
        string line;
        while (getline(file, line) && jumlahPengguna < MAX_PENGGUNA) {
            stringstream ss(line);
            string username, password;
            getline(ss, username, ',');
            getline(ss, password, ',');
            databasePengguna[jumlahPengguna].username = username;
            databasePengguna[jumlahPengguna].password = password;
            jumlahPengguna++;
        }
        file.close();
    } else {
        cout << "Database pengguna tidak ditemukan. Memulai dengan database kosong." << endl;
    }
}

// Fungsi untuk menyimpan keranjang pesanan ke dalam file CSV
void simpanKeranjangKeCSV(const Pengguna* pengguna) {
    ofstream file(pengguna->username + "_keranjang.csv");
    if (file.is_open()) {
        for (int i = 0; i < pengguna->jumlahSepatu; ++i) {
            file << pengguna->keranjang[i].merk << "," << pengguna->keranjang[i].harga << "," << pengguna->keranjang[i].stok << "\n";
        }
        file.close();
    } else {
        cout << "Gagal menyimpan keranjang ke file." << endl;
    }
}

// Fungsi untuk membaca keranjang pesanan dari file CSV
void bacaKeranjangDariCSV(Pengguna* pengguna) {
    ifstream file(pengguna->username + "_keranjang.csv");
    if (file.is_open()) {
        pengguna->jumlahSepatu = 0;
        string line;
        while (getline(file, line) && pengguna->jumlahSepatu < MAX_SEPATU) {
            stringstream ss(line);
            string merk, hargaStr, stokStr;
            getline(ss, merk, ',');
            getline(ss, hargaStr, ',');
            getline(ss, stokStr, ',');
            pengguna->keranjang[pengguna->jumlahSepatu].merk = merk;
            pengguna->keranjang[pengguna->jumlahSepatu].harga = stod(hargaStr);
            pengguna->keranjang[pengguna->jumlahSepatu].stok = stoi(stokStr);
            pengguna->jumlahSepatu++;
        }
        file.close();
    } else {
        cout << "Keranjang pesanan tidak ditemukan. Memulai dengan keranjang kosong." << endl;
    }
}

// Fungsi untuk menyimpan informasi checkout ke dalam file CSV
void simpanCheckoutKeCSV(const Pengguna* pengguna, Sepatu keranjangDipilih[], int jumlahDipilih) {
    ofstream file("checkout.csv", ios::app); // append mode
    if (file.is_open()) {
        for (int i = 0; i < jumlahDipilih; ++i) {
            file << pengguna->username << "," << keranjangDipilih[i].merk << "," << keranjangDipilih[i].harga << "," << keranjangDipilih[i].stok << "," << (keranjangDipilih[i].harga * keranjangDipilih[i].stok) << "\n";
        }
        file.close();
    } else {
        cout << "Gagal menyimpan checkout ke file." << endl;
    }
}

// Fungsi untuk menampilkan menu pembeli
void tampilkanMenuPembeli() {
    cout << "\n======= Menu Utama =========  " << endl;
    cout << "  1. Lihat Sepatu               " << endl;
    cout << "  2. Tambah/Beli Sepatu         " << endl;
    cout << "  3. Cari Sepatu                " << endl;
    cout << "  4. Lihat Keranjang Sepatu     " << endl;
    cout << "  5. Hapus Sepatu dari Keranjang" << endl;
    cout << "  6. Checkout Pesanan Sepatu    " << endl;
    cout << "  7. Update Keranjang Sepatu    " << endl;
    cout << "  8. Logout                     " << endl;
    cout << "Pilih: ";
}

// Fungsi untuk menampilkan semua sepatu dengan opsi pengurutan
void lihatSepatu() {
    int pilihanUrut;
    cout << "\nPilih urutan tampilan sepatu:" << endl;
    cout << "1. A-Z" << endl;
    cout << "2. Z-A" << endl;
    cout << "3. Harga Termurah ke Termahal" << endl;
    cout << "4. Harga Termahal ke Termurah" << endl;
    cout << "Masukkan pilihan (0 untuk kembali) : ";
    if (!(cin >> pilihanUrut) || (pilihanUrut < 0 || pilihanUrut > 4)) {
        cout << "Input tidak valid. Harap masukkan nomor yang benar." << endl;
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        return;
    }

    if (pilihanUrut == 0) return;
    // Mengurutkan berdasarkan pilihan
    switch (pilihanUrut) {
        case 1:
            sort(databaseSepatu, databaseSepatu + jumlahSepatu, [](const Sepatu& a, const Sepatu& b) {
                return a.merk < b.merk;
            });
            break;
        case 2:
            sort(databaseSepatu, databaseSepatu + jumlahSepatu, [](const Sepatu& a, const Sepatu& b) {
                return a.merk > b.merk;
            });
            break;
        case 3:
            sort(databaseSepatu, databaseSepatu + jumlahSepatu, [](const Sepatu& a, const Sepatu& b) {
                return a.harga < b.harga;
            });
            break;
        case 4:
            sort(databaseSepatu, databaseSepatu + jumlahSepatu, [](const Sepatu& a, const Sepatu& b) {
                return a.harga > b.harga;
            });
            break;
        default:
            break;
    }

    cout << "\n=== Daftar Sepatu ===" << endl;
    for (int i = 0; i < jumlahSepatu; ++i) {
        cout << i + 1 << ". Merek: " << databaseSepatu[i].merk << ", Harga: Rp" << databaseSepatu[i].harga << ", Stok: " << databaseSepatu[i].stok << endl;
    }
}

// Fungsi rekursif untuk mencari sepatu berdasarkan nama
int cariSepatu(const Sepatu arr[], int l, int r, const string& nama) {
    if (l > r) {
        return -1;
    }
    int mid = l + (r - l) / 2;
    if (arr[mid].merk == nama) {
        return mid;
    }
    if (arr[mid].merk > nama) {
        return cariSepatu(arr, l, mid - 1, nama);
    }
    return cariSepatu(arr, mid + 1, r, nama);
}

// Fungsi untuk membeli sepatu
void BeliSepatu(Pengguna* pengguna) {
    int pilihan;
    cout << "\nMasukkan nomor sepatu yang ingin dibeli (0 untuk kembali): ";
    if (!(cin >> pilihan) || pilihan < 0 || pilihan > jumlahSepatu) {
        cout << "Input tidak valid. Harap masukkan nomor yang benar." << endl;
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        return;
    }
    if (pilihan == 0) return;
    pilihan--; // mengurangi indeks untuk array

    int jumlahBeli;
    cout << "Masukkan jumlah yang ingin dibeli: ";
    if (!(cin >> jumlahBeli) || jumlahBeli < 1 || jumlahBeli > databaseSepatu[pilihan].stok ) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        return;
    }

    // Menambahkan ke keranjang pengguna
    bool sudahAda = false;
    for (int i = 0; i < pengguna->jumlahSepatu; ++i) {
        if (pengguna->keranjang[i].merk == databaseSepatu[pilihan].merk) {
            pengguna->keranjang[i].stok += jumlahBeli;
            sudahAda = true;
            break;
        }
    }
    if (!sudahAda) {
        pengguna->keranjang[pengguna->jumlahSepatu] = databaseSepatu[pilihan];
        pengguna->keranjang[pengguna->jumlahSepatu].stok = jumlahBeli;
        pengguna->jumlahSepatu++;
    }

    // Mengurangi stok di database
    databaseSepatu[pilihan].stok -= jumlahBeli;

    cout << "Sepatu berhasil ditambahkan ke keranjang." << endl;
    simpanKeranjangKeCSV(pengguna); // Menyimpan keranjang ke file CSV
}

// Fungsi untuk melihat keranjang sepatu
void lihatKeranjang(const Pengguna* pengguna) {
    cout << "\n=== Keranjang Sepatu Anda ===" << endl;
    if (pengguna->jumlahSepatu == 0) {
        cout << "Keranjang kosong." << endl;
        return;
    }

    double totalHarga = 0.0;
    for (int i = 0; i < pengguna->jumlahSepatu; ++i) {
        cout << i + 1 << ". Merek: " << pengguna->keranjang[i].merk << ", Harga: Rp" << fixed << setprecision(2) << pengguna->keranjang[i].harga << ", Jumlah: " << pengguna->keranjang[i].stok << ", Total: Rp" << fixed << setprecision(2) << (pengguna->keranjang[i].harga * pengguna->keranjang[i].stok) << endl;
        totalHarga += pengguna->keranjang[i].harga * pengguna->keranjang[i].stok;
    }
    cout <<  "Total Harga: Rp" << fixed << setprecision(2) << totalHarga << endl;
}

// Fungsi untuk menghapus sepatu dari keranjang
void hapusSepatuDariKeranjang(Pengguna* pengguna) {
    lihatKeranjang(pengguna);
    if (pengguna->jumlahSepatu == 0) {
        return;
    }

    int pilihan;
    cout << "\nMasukkan nomor sepatu yang ingin dihapus (0 untuk kembali): ";
    if (!(cin >> pilihan) || pilihan < 0 || pilihan > jumlahSepatu> pengguna->jumlahSepatu) {
        cout << "Input tidak valid. Harap masukkan nomor yang benar." << endl;
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        return;
    }
    if (pilihan == 0) return;
    pilihan--; // mengurangi indeks untuk array

    // Mengembalikan stok ke database
    for (int i = 0; i < jumlahSepatu; ++i) {
        if (databaseSepatu[i].merk == pengguna->keranjang[pilihan].merk) {
            databaseSepatu[i].stok += pengguna->keranjang[pilihan].stok;
            break;
        }
    }

    // Menghapus sepatu dari keranjang
    for (int i = pilihan; i < pengguna->jumlahSepatu - 1; ++i) {
        pengguna->keranjang[i] = pengguna->keranjang[i + 1];
    }
    pengguna->jumlahSepatu--;

    cout << "Sepatu berhasil dihapus dari keranjang." << endl;
    simpanKeranjangKeCSV(pengguna); // Menyimpan keranjang ke file CSV
}

// Fungsi untuk melakukan checkout pesanan sepatu
void checkoutSepatu(Pengguna* pengguna) {
    lihatKeranjang(pengguna);
    if (pengguna->jumlahSepatu == 0) {
        return;
    }

    char konfirmasi;
    cout << "Apakah Anda yakin ingin melakukan checkout? (y/n): ";
    cin >> konfirmasi;
    if (konfirmasi == 'y' || konfirmasi == 'Y') {
        simpanCheckoutKeCSV(pengguna, pengguna->keranjang, pengguna->jumlahSepatu); // Menyimpan checkout ke file CSV
        cout << "Checkout berhasil. Terima kasih sudah berbelanja." << endl;
        pengguna->jumlahSepatu = 0; // Mengosongkan keranjang setelah checkout
        simpanKeranjangKeCSV(pengguna); // Menghapus keranjang dari file CSV
    } else {
        cout << "Checkout dibatalkan." << endl;
    }
}

// Fungsi untuk mengupdate keranjang sepatu
void updateKeranjang(Pengguna* pengguna) {
    lihatKeranjang(pengguna);
    if (pengguna->jumlahSepatu == 0) {
        return;
    }

    int pilihan;
    cout << "\nMasukkan nomor sepatu yang ingin diupdate (0 untuk kembali): ";
    if (!(cin >> pilihan) || pilihan < 0 || pilihan > pengguna->jumlahSepatu) {
        cout << "Input tidak valid. Harap masukkan nomor yang benar." << endl;
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        return;
    }
    if (pilihan == 0) return;
    pilihan--; // mengurangi indeks untuk array

    int jumlahBaru;
    cout << "Masukkan jumlah baru: ";
    if (!(cin >> jumlahBaru) || jumlahBaru < 1 || jumlahBaru > 10) {
        cout << "Jumlah tidak valid. Pembelian dibatasi maksimal 10 stok." << endl;
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        return;
    }

    // Mengupdate merek dan jumlah di keranjang
    pengguna->keranjang[pilihan].stok = jumlahBaru;

    cout << "Keranjang berhasil diupdate." << endl;
    simpanKeranjangKeCSV(pengguna); // Menyimpan keranjang ke file CSV
}

// Fungsi untuk login
bool login(Pengguna*& penggunaSaatIni) {
    string username, password;
    cout << "Masukkan username: ";
    cin >> username;
    cout << "Masukkan password: ";
    cin >> password;

    for (int i = 0; i < jumlahPengguna; ++i) {
        if (databasePengguna[i].username == username && databasePengguna[i].password == password) {
            penggunaSaatIni = &databasePengguna[i];
            bacaKeranjangDariCSV(penggunaSaatIni); // Membaca keranjang dari file CSV
            return true;
        }
    }

    return false;
}

// Fungsi untuk mendaftar
bool daftar() {
    if (jumlahPengguna >= MAX_PENGGUNA) {
        cout << "Database pengguna penuh. Tidak bisa mendaftar pengguna baru." << endl;
        return false;
    }

    string username, password;
    cout << "Masukkan username baru: ";
    cin >> username;
    cout << "Masukkan password baru: ";
    cin >> password;

    for (int i = 0; i < jumlahPengguna; ++i) {
        if (databasePengguna[i].username == username) {
            cout << "Username sudah terdaftar. Coba dengan username lain." << endl;
            return false;
        }
    }

    databasePengguna[jumlahPengguna].username = username;
    databasePengguna[jumlahPengguna].password = password;
    jumlahPengguna++;
    simpanDatabasePenggunaKeCSV();
    return true;
}

// Fungsi utama
int main() {
    bacaDatabasePenggunaDariCSV();

    Pengguna* penggunaSaatIni = nullptr;
    while (true) {
        int pilihan;
        cout << "\n======= Selamat Datang Di Sistem Toko Sepatu =======" << endl;
        cout << "1. Login" << endl;
        cout << "2. Daftar" << endl;
        cout << "3. Keluar" << endl;
        cout << "Pilih: ";
        if (!(cin >> pilihan) || pilihan < 1 || pilihan > 3) {
            cout << "Input tidak valid. Harap masukkan nomor yang benar." << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        }

        switch (pilihan) {
            case 1:
                if (login(penggunaSaatIni)) {
                    cout << "Login berhasil." << endl;
                    bool loggedIn = true;
                    while (loggedIn) {
                        tampilkanMenuPembeli();
                        int pilihanPembeli;
                        if (!(cin >> pilihanPembeli)) {
                            cout << "Input tidak valid. Harap masukkan nomor yang benar." << endl;
                            cin.clear();
                            cin.ignore(numeric_limits<streamsize>::max(), '\n');
                            continue;
                        }
                        switch (pilihanPembeli) {
                            case 1:
                                lihatSepatu();
                                break;
                            case 2:
                                BeliSepatu(penggunaSaatIni);
                                break;
                            case 3: {
                                string nama;
                                cout << "Masukkan nama sepatu yang dicari: ";
                                cin >> nama;
                                int hasilCari = cariSepatu(databaseSepatu, 0, jumlahSepatu - 1, nama);
                                if (hasilCari != -1) {
                                    cout << "Sepatu ditemukan: " << databaseSepatu[hasilCari].merk << ", Harga: Rp" << databaseSepatu[hasilCari].harga << ", Stok: " << databaseSepatu[hasilCari].stok << endl;
                                } else {
                                    cout << "Sepatu tidak ditemukan." << endl;
                                }
                                break;
                            }
                            case 4:
                                lihatKeranjang(penggunaSaatIni);
                                break;
                            case 5:
                                hapusSepatuDariKeranjang(penggunaSaatIni);
                                break;
                            case 6:
                                checkoutSepatu(penggunaSaatIni);
                                break;
                            case 7:
                                updateKeranjang(penggunaSaatIni);
                                break;
                            case 8:
                                loggedIn = false;
                                penggunaSaatIni = nullptr;
                                cout << "Logout berhasil." << endl;
                                break;
                            default:
                                cout << "Pilihan tidak valid. Harap masukkan nomor yang benar." << endl;
                                break;
                        }
                    }
                } else {
                    cout << "Username atau password salah." << endl;
                }
                break;
            case 2:
                if (daftar()) {
                    cout << "Pendaftaran berhasil. Silakan login." << endl;
                } else {
                    cout << "Pendaftaran gagal." << endl;
                }
                break;
            case 3:
                cout << "Terima kasih telah menggunakan program ini." << endl;
                return 0;
        }
    }
}
